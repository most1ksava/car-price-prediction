import mlflow
import mlflow.sklearn
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OrdinalEncoder
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Настройка MLflow
mlflow.set_tracking_uri("http://localhost:5000")
mlflow.set_experiment("car_price_prediction")

def prepare_data(data):
    # Преобразование категориальных признаков
    categorical_features = ['vehicle_type', 'gearbox', 'model', 'fuel_type', 'brand', 'repaired']
    
    # Заполнение пропущенных значений
    for col in categorical_features:
        data[col] = data[col].fillna('unknown')
    
    # Кодирование категориальных признаков
    encoder = OrdinalEncoder()
    data[categorical_features] = encoder.fit_transform(data[categorical_features])
    
    # Числовые признаки
    numeric_features = ['registration_year', 'power', 'kilometer', 'registration_month']
    
    # Стандартизация числовых признаков
    scaler = StandardScaler()
    data[numeric_features] = scaler.fit_transform(data[numeric_features])
    
    return data, encoder, scaler

def train_model():
    # Загрузка данных
    data = pd.read_csv("autos.csv")
    
    # Подготовка данных
    features = ['vehicle_type', 'registration_year', 'gearbox', 'power', 'model',
                'kilometer', 'registration_month', 'fuel_type', 'brand', 'repaired']
    target = 'price'
    
    # Подготовка признаков
    X = data[features]
    y = data[target]
    
    # Разделение на обучающую и тестовую выборки
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Подготовка данных
    X_train, encoder, scaler = prepare_data(X_train)
    X_test = prepare_data(X_test)[0]
    
    # Параметры модели
    model_params = {
        'iterations': 1000,
        'learning_rate': 0.1,
        'depth': 6,
        'loss_function': 'RMSE',
        'verbose': False
    }
    
    # Обучение модели
    with mlflow.start_run():
        model = CatBoostRegressor(**model_params)
        model.fit(X_train, y_train)
        
        # Предсказания
        train_predictions = model.predict(X_train)
        test_predictions = model.predict(X_test)
        
        # Метрики
        train_rmse = np.sqrt(mean_squared_error(y_train, train_predictions))
        test_rmse = np.sqrt(mean_squared_error(y_test, test_predictions))
        train_r2 = r2_score(y_train, train_predictions)
        test_r2 = r2_score(y_test, test_predictions)
        
        # Логирование параметров и метрик
        mlflow.log_params(model_params)
        mlflow.log_metric("train_rmse", train_rmse)
        mlflow.log_metric("test_rmse", test_rmse)
        mlflow.log_metric("train_r2", train_r2)
        mlflow.log_metric("test_r2", test_r2)
        
        # Сохранение модели
        mlflow.sklearn.log_model(model, "model")
        
        # Сохранение препроцессоров
        mlflow.log_artifact("encoder.joblib")
        mlflow.log_artifact("scaler.joblib")
        
        print(f"Training RMSE: {train_rmse}")
        print(f"Test RMSE: {test_rmse}")
        print(f"Training R2: {train_r2}")
        print(f"Test R2: {test_r2}")

if __name__ == "__main__":
    train_model() 